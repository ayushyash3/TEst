package stepDefinations;

import java.io.IOException;

import io.cucumber.java.Before;

public class Hook {
	
	@Before("@Deleteplace")
	public void beforescenario() throws IOException
	{
	StepDefination step = new StepDefination();
	
	if (StepDefination.placeid == null)
	{
		step.add_place_payload_with("ayush", "hindi", "c108");
		step.user_call_with_http_request("Addplaceapi", "Post");
		step.verify_place_id_created_map_to_using("ayush", "Getplaceapi");
	}
	}

	@Before("@Updateaddress")
	public void beforeupdate() throws IOException
	{
	StepDefination step = new StepDefination();
	
	if (StepDefination.placeid == null)
	{
		step.add_place_payload_with("ayush", "hindi", "c108");
		step.user_call_with_http_request("Addplaceapi", "Post");
		step.verify_place_id_created_map_to_using("ayush", "Getplaceapi");
	}
	}
	
}
