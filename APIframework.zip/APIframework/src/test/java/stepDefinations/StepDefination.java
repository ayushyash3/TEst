package stepDefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import resources.Resourceapi;
import resources.Rutlity;
import resources.Testdata;
import static org.junit.Assert.*;
import static io.restassured.RestAssured.*;

import java.io.FileNotFoundException;
import java.io.IOException;


public class StepDefination extends Rutlity{
	Testdata data = new Testdata();
	 RequestSpecification res;
	 ResponseSpecification rsp;
	 Response response;
	 static String placeid;
	@Given("Add place payload with {string} {string} {string}")
	public void add_place_payload_with(String name, String language, String address) throws IOException {
			res = given().spec(reqestspcbulder())
					.body(data.addplacepaylaod(name, language, address));
			
		}

	@When("user call {string} with {string} http request")
	public void user_call_with_http_request(String str1, String string2)  {
	   Resourceapi rspapi = Resourceapi.valueOf(str1);
	   System.out.println(rspapi.getresource());
	   
	   rsp = new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON).build();
	   
	   if(string2.equalsIgnoreCase("Post"))
	   {
	
		response= res.when().post(rspapi.getresource());
	   }
	   else if(string2.equalsIgnoreCase("Get"))
	   {

		response= res.when().get(rspapi.getresource());
	   }  
	   
	   else if(string2.equalsIgnoreCase("Put"))
	   {

		response= res.when().put(rspapi.getresource());
	   } 
	}

	@Then("Api call got successfully placed")
	public void api_call_got_successfully_placed() {
	  assertEquals(response.getStatusCode(),200);
	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String string, String string2) {
	
	   assertEquals(getJson(response,string),string2);
	}
	
	@Then("verify place_id created map to {string} using {string}")
	public void verify_place_id_created_map_to_using(String expectedname, String string2) throws IOException {
		placeid = getJson(response,"place_id");
		res = given().spec(reqestspcbulder()).queryParam("place_id",placeid);
		user_call_with_http_request(string2,"Get");
		String acutalname = getJson(response,"name");
		assertEquals(acutalname,expectedname);
		
	}

	@Given("Delete api working fine")
	public void delete_api_working_fine() throws IOException {
	
		res = given().spec(reqestspcbulder()).body(data.deleteplacepayload(placeid));
		
	}

	@Given("update address payload with {string} using {string}")
	public void update_address_payload_with_using(String address, String string2) throws IOException {
		res = given().spec(reqestspcbulder())
						.body(data.updateaddpayload(placeid, address));			
		
	}

	@Then("Verify address got successfully updated {string} using {string}")
	public void verify_address_got_successfully_updated_using(String address, String Getplaceapi) throws IOException {
		res = given().spec(reqestspcbulder()).queryParam("place_id",placeid);
		user_call_with_http_request(Getplaceapi,"Get");
		String acutalname = getJson(response,"address");
		assertEquals(acutalname,address);
		
	}
	
}
