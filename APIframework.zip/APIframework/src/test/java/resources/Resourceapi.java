package resources;

public enum Resourceapi {
	
	Addplaceapi("/maps/api/place/add/json"),
	Deleteplaceapi("/maps/api/place/delete/json"),
	Getplaceapi("/maps/api/place/get/json"),
	Updateaddressapi("/maps/api/place/update/json");
	
	private String resource;
	Resourceapi(String resource)
	{
		this.resource = resource;
	}
	
	public String getresource()
	{
		return resource;
	}
}

