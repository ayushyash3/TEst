package resources;

import java.util.ArrayList;
import java.util.List;

import pojo.Addplace;
import pojo.Location;

public class Testdata {
	
	public Addplace addplacepaylaod(String name, String language, String address)
	
	{
		Addplace place = new Addplace();
		Location loc = new Location();
		place.setAccuracy(50);
		place.setName(name);
		place.setPhone_number("(+91) 983 893 3937");
		place.setAddress(address);
		loc.setLat(-38.383494);
		loc.setLng(33.427362);
		place.setLocation(loc);
		place.setWebsite("http://google.com");
		place.setLanguage(language);
		List<String> mylist = new ArrayList<String>();
		mylist.add("shoe park");
		mylist.add("shop");
		place.setTypes(mylist);
		return place;
		
	}
	
	public String deleteplacepayload(String placeid)
	{
		return "{\"place_id\":\""+ placeid + "\"}";
	}
	
	
	public String updateaddpayload(String placeid, String address)
	{
		{
			return "{\r\n" + 
			"\"place_id\":\""+placeid+"\",\r\n" + 
			"\"address\":\""+address+ "\",\r\n" + 
			"\"key\":\"qaclick123\"\r\n" + 
			"}\r\n" + 
			"";
			}
		
		
		
	}
}
