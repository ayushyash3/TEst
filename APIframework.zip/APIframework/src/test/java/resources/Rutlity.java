package resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Rutlity {
	public static RequestSpecification spc;
		public RequestSpecification reqestspcbulder() throws IOException
	{
	if(spc == null)
	{
	PrintStream log = new PrintStream(new FileOutputStream("apilogs.txt"));	
	 spc = new RequestSpecBuilder().setBaseUri(getglobalvalue("baseurl"))
	.addQueryParam("key", "qaclick123")
	.addFilter(RequestLoggingFilter.logRequestTo(log))
	.addFilter(ResponseLoggingFilter.logResponseTo(log))
	.setContentType(ContentType.JSON).build();
	 return spc;
	}
	return spc;
	}

		
	public static String getglobalvalue(String key) throws IOException
	{
		Properties prop = new Properties();
		FileInputStream ft = new FileInputStream("C:\\Users\\ayush.maheshwari\\eclipse-workspace_jan\\APIframework\\src\\test\\java\\resources\\Gobal.properties");
		prop.load(ft);
		return prop.getProperty(key);
			
	}
	
	public String getJson(Response response, String key)
	
	{
		String repp = response.asString();
		JsonPath js = new JsonPath(repp);
		return js.get(key).toString();
	}
	
}
